"""GamingIdleon sprite clicker."""

